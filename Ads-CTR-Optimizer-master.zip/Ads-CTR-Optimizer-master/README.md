# Ads-CTR-Optimizer
Applying Reinforcement lerning on social network ads to predict most suited ad for the user.
